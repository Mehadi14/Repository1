package BrowserSatckApis.DemoApis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoApisApplicationTests {

	@Test
	void contextLoads() {
	}

}
